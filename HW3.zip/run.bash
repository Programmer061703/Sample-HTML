.#!/bin/bash
set -u -e
tsc --strict turtle.ts
open TurtleAttack!.html
