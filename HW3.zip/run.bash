.#!/bin/bash
set -u -e
tsc turtle.ts
open TurtleAttack!.html
