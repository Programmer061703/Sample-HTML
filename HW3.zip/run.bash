.#!/bin/bash
set -u -e
tsc turtle.ts
start TurtleAttack!.html
